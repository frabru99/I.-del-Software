Per gli inserimenti del DB, consigliamo fortemente di usare gli insert nel .txt invece che i file csv, dopo aver importato lo schema di riferimento.
